<?php
// Heading
$_['heading_title']               = 'Product Chat  Gemini';

// Text
$_['text_extension']              = 'Extensions';
$_['text_success']                = 'تم تعديل بنجاح  Product Chat  Gemini module!';
$_['text_edit']                   = 'Product تعديل  Chat  Gemini Module';

// Entry
$_['entry_status']                = 'حالة';
$_['entry_api_key']               = 'Gemini API Key';
$_['entry_content_result']        = 'Gemini Response';

// Error
$_['error_api_key']               = 'Gemini API Key مطلوب';
$_['error_permission']            = 'لاتملك صلاحيات تعديل  Chat  Gemini!';
